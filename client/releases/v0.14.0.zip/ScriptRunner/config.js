module.exports = {
	server: {
		protocol: 'http',
		host: 'granny.io',
		port: 80,
		path: ''
	},
	driver: {
		findElementTimeout: 15000,
		performActionTimeout: 15000
	}
};