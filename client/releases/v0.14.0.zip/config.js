module.exports = {
	server: {
		protocol: 'http',
		host: '0.0.0.0',
		port: 3000,
		path: ''
	},
	driver: {
		findElementTimeout: 15000,
		performActionTimeout: 15000
	}
};